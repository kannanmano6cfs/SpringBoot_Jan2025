package com.example.serv_loanreq.Controller;

import com.example.serv_loanreq.Model.reqDetails;
import com.example.serv_loanreq.Repository.reqDetailsRepository;
import jakarta.transaction.Transactional;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping(("/loanreq"))
public class loanreqController {

    public String msg;

    @Autowired
    private Environment environment;

    @Autowired
    private reqDetailsRepository repo;

    @GetMapping("/welcome")
    public String welcome() {
        msg= environment.getProperty("welcome.msg");
        return msg;
    }

    @GetMapping("/getreqcount")
    public ResponseEntity<String> getreqcount() {
        long ct= repo.count();
        return new ResponseEntity<>("Count of loan request is :"+ct, HttpStatus.OK);
    }

    @GetMapping("/getreqdetails")
    public Iterable<reqDetails> getreqdetails() {
        Iterable<reqDetails> reqdetails= repo.findAll();
        return reqdetails;
    }

    @GetMapping("/getreqdetbyId/{id}")
    public reqDetails getreqdetbyId(@PathVariable int id) {
        Optional<reqDetails> reqdetails= repo.findById(id);
        return reqdetails.orElseThrow();
    }

    @GetMapping("/getreqdetbygname")
    public Iterable<reqDetails> getreqdetbygname(@RequestParam String gn) {
        Iterable<reqDetails> reqDetails=repo.findBygName(gn);
        return reqDetails;
    }

    @PostMapping("/sendreqdetails")
    public ResponseEntity<String> sendreqdetails(@RequestBody reqDetails reqdetails) {
        repo.save(reqdetails);
        return  new ResponseEntity<>("Request Details Sent successfully", HttpStatus.OK);
    }

    @PostMapping("/sendreqdetailsnew")
    public ResponseEntity<String> sendreqdetailsnew() {
        reqDetails reqDetail=new reqDetails();
        reqDetail.setgName("Varan01");
        reqDetail.setReqDate("24-01-25");
        reqDetail.setReqName("Topup");
        reqDetail.setLoanAmount(15000.00);
        reqDetail.setReqStatus("Requested");
        repo.save(reqDetail);
        return  new ResponseEntity<>("Request Details Sent successfully", HttpStatus.OK);
    }

    @PutMapping("/updatereqdetails/{id}")
    public ResponseEntity<String> updatereqdetails(@RequestBody reqDetails reqdetails1, @PathVariable int id) {
        reqDetails reqdetails2=repo.findById(id).orElseThrow();
        reqdetails2.setLoanAmount(reqdetails1.getLoanAmount());
        reqdetails2.setReqName(reqdetails1.getReqName());
        reqdetails2.setReqDate(reqdetails1.getReqDate());
        repo.save(reqdetails2);
        return  new ResponseEntity<>("Request Details Updated successfully", HttpStatus.OK);
    }

    @DeleteMapping("/deleterequest/{id}")
    public ResponseEntity<String> deleterequest(@PathVariable int id) {
        repo.deleteById(id);
        return  new ResponseEntity<>("Request Details Deleted successfully", HttpStatus.OK);
    }

    @DeleteMapping("/deletegroupreq/{gn}")
    @Transactional
    public ResponseEntity<String> deletegroupreq(@PathVariable String gn) {
        repo.deleteBygName(gn);
        return new ResponseEntity<>("Group Request Details Deleted successfully", HttpStatus.OK);
    }
}
