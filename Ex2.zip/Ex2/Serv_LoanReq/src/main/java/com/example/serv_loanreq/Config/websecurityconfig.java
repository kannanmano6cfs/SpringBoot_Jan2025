package com.example.serv_loanreq.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class websecurityconfig {
    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails user1= User.withDefaultPasswordEncoder()
                .username("user")
                .password("user")
                .roles("USER")
                .build();

        UserDetails user2= User.withDefaultPasswordEncoder()
                .username("member")
                .password("member")
                .roles("MEMBER")
                .build();

        UserDetails user3= User.withDefaultPasswordEncoder()
                .username("admin")
                .password("admin")
                .roles("ADMIN")
                .build();
        return new InMemoryUserDetailsManager(user1, user2, user3);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests((auth)-> auth
                .requestMatchers("/loanreq/welcome").permitAll()
                .requestMatchers("/loanreq/getreqcount").hasAnyRole("USER", "ADMIN")
                .requestMatchers("/loanreq/getreqdetails").hasAnyRole("USER","ADMIN")
                .requestMatchers("/loanreq/deleterequest/*").hasRole("ADMIN"))
                .httpBasic(Customizer.withDefaults());
        return http.build();
    }

}
