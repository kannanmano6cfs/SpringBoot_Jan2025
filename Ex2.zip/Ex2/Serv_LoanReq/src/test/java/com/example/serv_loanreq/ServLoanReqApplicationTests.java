package com.example.serv_loanreq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServLoanReqApplicationTests {

	@Test
	void contextLoads() {
	}

}
