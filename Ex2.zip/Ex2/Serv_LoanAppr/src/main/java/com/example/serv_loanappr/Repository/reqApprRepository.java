package com.example.serv_loanappr.Repository;

import com.example.serv_loanappr.Model.reqAppr;
import org.springframework.data.repository.CrudRepository;

public interface reqApprRepository extends CrudRepository<reqAppr, Integer> {

}
