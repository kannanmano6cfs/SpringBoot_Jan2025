package com.example.serv_loanreq;

//import com.example.serv_loanreq.Config.websecurityconfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Import;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EntityScan("com.example")
//@EnableWebSecurity
//@Import(websecurityconfig.class)
public class ServLoanReqApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServLoanReqApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
