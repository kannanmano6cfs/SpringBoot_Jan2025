package com.example.serv_loanreq.Repository;

import com.example.serv_loanreq.Model.reqDetails;
import org.springframework.data.repository.CrudRepository;

public interface reqDetailsRepository extends CrudRepository<reqDetails,Integer> {

    Iterable<reqDetails> findBygName(String name);
    void deleteBygName(String name);
}
