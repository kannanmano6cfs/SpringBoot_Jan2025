package com.example.serv_loanreq.Model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class womenGroup {

    private int group_id;
    private String group_name;
    private String form_date;
    private int strength;
    private String place;

}
