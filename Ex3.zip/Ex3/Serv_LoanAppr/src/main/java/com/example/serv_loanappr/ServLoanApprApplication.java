package com.example.serv_loanappr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ServLoanApprApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServLoanApprApplication.class, args);
	}

}
