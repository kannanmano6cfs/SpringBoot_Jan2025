package com.example.serv_loanappr.Controller;

import com.example.serv_loanappr.Model.reqAppr;
import com.example.serv_loanappr.Model.reqDetails;
import com.example.serv_loanappr.Repository.reqApprRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/loanappr")
public class loanapprController {

    @Autowired
    private reqApprRepository repo;

   
    @PostMapping("/sendapprreq")
    public ResponseEntity<String> sendapprreq(@RequestBody reqDetails reqDetails) {
        reqAppr reqappr = new reqAppr();
        reqappr.setReqId(reqDetails.getReqId());
        reqappr.setgName(reqDetails.getgName());
        reqappr.setLoanAmount(reqDetails.getLoanAmount());
        reqappr.setReqDate(reqDetails.getReqDate());
        reqappr.setApprDate("Not_Updated");
        reqappr.setApprStatus("Requested");
        repo.save(reqappr);
        return new ResponseEntity<>("Loan request obtained for approval", HttpStatus.OK);
}
}
